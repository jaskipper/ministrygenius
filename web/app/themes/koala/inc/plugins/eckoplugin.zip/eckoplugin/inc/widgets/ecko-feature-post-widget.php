<?php

	/*-----------------------------------------------------------------------------------*/
	/* FEATURE POST WIDGET
	/*-----------------------------------------------------------------------------------*/

	class ecko_widget_feature_post extends WP_Widget{

		function __construct(){
			parent::__construct(
				'ecko_widget_feature_post',
				'Ecko Feature Post',
				array('description' => 'Display a chosen feature post.')
			);
		}

		public function widget($args, $instance){
			if(isset($instance['postid'])){
				global $post;
				$post = get_post($instance['postid']);
				if(count($post)){
					setup_postdata($post);
					?>
					<section class="widget widget-feature-post">
						<div class="widget-feature-post-background" style="background-image:url('<?php echo esc_url(ecko_get_post_image(false, 'ecko_opengraph')); ?>');"></div>
						<div class="widget-feature-post-gradient"></div>
						<a href="<?php the_permalink(); ?>" class="widget-feature-post-info">
							<div class="widget-feature-post-lower">
								<div class="widget-feature-post-title"><?php esc_html_e("Featured Post", 'eckoplugin'); ?></div>
								<h3 class="post-title"><?php the_title(); ?></h3>
								<?php
									$post_category = get_the_category($post->ID);
									echo '<span class="post-category" style="background:#' . esc_attr(ecko_get_category_color_by_postid($postid)) . ';" data-category-color="#' . esc_attr(ecko_get_category_color_by_postid($postid)) . '">' . esc_html($post_category[0]->name) . '</span>';
								?>
							</div>
						</a>
					</section>
					<?php
				}
				wp_reset_postdata();
			}
		}

		public function form($instance){
			$defaults = array(
				'postid' => ''
			);
			$instance = wp_parse_args((array)$instance, $defaults);
			?>
				<p>
					<label for="<?php echo $this->get_field_id('postid'); ?>">Post ID: </label>
					<input class="widefat" id="<?php echo $this->get_field_id('postid'); ?>" name="<?php echo $this->get_field_name('postid'); ?>" type="text" value="<?php echo esc_attr($instance['postid']); ?>" />
				</p>
			<?php
		}

		public function update($new_instance, $old_instance){
			$instance = array();
			foreach($new_instance as $key => $value){
				$instance[$key] = (!empty($new_instance[$key])) ? strip_tags($new_instance[$key]) : '';
			}
			return $instance;
		}

	}

?>
